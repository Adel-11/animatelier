# Pipeline QFF (Quiz Factory Forever)

**Lire `qff-pipeline/HANDOVER.md` en premier** : il contient la passation complète du 23 septembre 2026
(outil, chaîne de production, n8n, images, vidéos publiées, points ouverts).

Ce README décrivait l'ancienne méthode (générateur `gen_lv.js` hors dépôt, rendu, incrustation ffmpeg du logo).
Elle est remplacée depuis le 21 septembre par le CLI d'Animatelier :

```sh
node apps/cli/quiz-video.js spec.json --out out/ --assets-dir img/ \
  --voice-durations voice-durations.json --sfx default --preview auto \
  --cover-image brands/qff/logo.png --jobs 4
node apps/cli/mux-audio.js out/video.mp4 --audio voix-musique.wav --out final.mp4 --keep-sfx
```

Les anciens fichiers `gen_lv.js`, `tts_lv.py`, `audio_lv.py`, `spec-exemple.json` et `speech-exemple.json`
restent dans ce dossier comme référence de mise en page et de minutage. La partie musique d'`audio_lv.py`
est toujours utilisée, extraite dans `make_music.py`.

## Couleurs (logo)

Fond #07275F, panneaux #0F3678, texte #FDF8E3, jaune #FECD1B.
Niveaux : ROOKIE #3DDC97, MASTER #FF8A3D, GOAT #FF4D6D.

## Publication (n8n)

Workflow « QFF - Publier Reel » (id m2aUOyCJcd0xNJY5), webhook POST `/webhook/qff-publish?key=...`.
Corps : `video` (multipart) ou `video_url`, `caption`, `dry_run`, `facebook`.
Détail des nœuds, des contraintes d'encodage et des pannes connues dans HANDOVER.md.

## Historique

- 21 sept. 2026 : domaine n8n.letter-bird.com autorisé. Premier Reel publié
  (https://www.instagram.com/reel/Ddja5bsCWg1/). Facebook bloqué (erreur 368 anti-spam) après une boucle de test.
- 22 sept. 2026 : quiz logos v2 (https://www.instagram.com/reel/DdkHZYSAalh/).
- 22 sept. 2026 : quiz culture générale avec QCM, images et effets (https://www.instagram.com/reel/DdnHGZgDBjw/).
- 23 sept. 2026 : quiz « devine la star à ses yeux » (https://www.instagram.com/reel/DdnVJ1vE6nC/).
  Facebook toujours bloqué à cette date.
